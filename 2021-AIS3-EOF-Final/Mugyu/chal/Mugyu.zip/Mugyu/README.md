# Mugyu
## Usage
```bash
./mugyu n3k0
```